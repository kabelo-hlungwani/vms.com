window.onload = function () {
    var de = document.getElementById("DivPreloader");
    de.style.display = 'none';
};