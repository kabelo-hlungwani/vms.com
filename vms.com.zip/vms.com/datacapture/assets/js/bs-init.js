$(document).ready(function(){
	AOS.init();
	$('[data-bss-tooltip]').tooltip();
});